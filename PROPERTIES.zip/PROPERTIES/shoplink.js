export const appname = {
    link: "https://shop.spatulaonline.com/"
};